STUDENT PERFORMANCE DATA CLEANING & VISUALIZATION
=================================================

FILES:
1. Student_Performance_Project_Report.pdf
   - Final written report with charts, findings and conclusion.

2. Student_Performance_Analysis.ipynb
   - Complete Python/Jupyter notebook containing data cleaning,
     outlier detection, analysis and visualization code.

3. StudentsPerformance.csv
   - Original raw dataset.

4. cleaned_students_performance.csv
   - Cleaned dataset used for analysis.

5. Student_Performance_Analysis.xlsx
   - Cleaned data and analysis tables in Excel format.

6. Student_Performance_Dashboard.png
   - One-page visual dashboard.

7. 01_average_by_subject.png to 08_correlation.png
   - Individual project charts.

SUBMISSION:
If your portal accepts multiple files, submit the PDF report, notebook,
cleaned CSV and dashboard. If it accepts only one file, upload the ZIP
package created with this project.

SOURCE:
Students Performance in Exams dataset. The dataset description reports
1,000 observations and variables covering demographics, parental education,
lunch, test preparation and three exam scores.
